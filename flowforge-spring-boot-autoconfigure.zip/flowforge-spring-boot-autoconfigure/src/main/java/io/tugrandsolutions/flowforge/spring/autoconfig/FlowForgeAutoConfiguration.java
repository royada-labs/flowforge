package io.tugrandsolutions.flowforge.spring.autoconfig;

import io.tugrandsolutions.flowforge.spring.bootstrap.TaskScanner;
import io.tugrandsolutions.flowforge.spring.bootstrap.WorkflowPlanRegistrar;
import io.tugrandsolutions.flowforge.spring.registry.DefaultWorkflowPlanRegistry;
import io.tugrandsolutions.flowforge.spring.registry.TaskHandlerRegistry;
import io.tugrandsolutions.flowforge.spring.registry.WorkflowPlanRegistry;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
public class FlowForgeAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public TaskHandlerRegistry taskHandlerRegistry() {
        return new TaskHandlerRegistry();
    }

    @Bean
    @ConditionalOnMissingBean
    public TaskScanner flowForgeTaskScanner(ApplicationContext ctx, TaskHandlerRegistry registry) {
        return new TaskScanner(ctx, registry);
    }

    @Bean
    @ConditionalOnMissingBean
    public WorkflowPlanRegistry workflowPlanRegistry() {
        return new DefaultWorkflowPlanRegistry();
    }

    @Bean
    public WorkflowPlanRegistrar workflowPlanRegistrar(WorkflowPlanRegistry registry) {
        return new WorkflowPlanRegistrar(registry);
    }
}