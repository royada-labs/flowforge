package io.tugrandsolutions.flowforge.spring.registry;

import io.tugrandsolutions.flowforge.task.TaskId;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public final class TaskHandlerRegistry {

    private final Map<TaskId, RegisteredTaskHandler> byId = new ConcurrentHashMap<>();

    public void register(RegisteredTaskHandler handler) {
        RegisteredTaskHandler prev = byId.putIfAbsent(handler.id(), handler);
        if (prev != null) {
            throw new IllegalStateException("Duplicate FlowTask id: " + handler.id());
        }
    }

    public Optional<RegisteredTaskHandler> find(TaskId id) {
        return Optional.ofNullable(byId.get(id));
    }

    public boolean contains(TaskId id) {
        return byId.containsKey(id);
    }

    public Map<TaskId, RegisteredTaskHandler> snapshot() {
        return Map.copyOf(byId);
    }
}