package io.tugrandsolutions.flowforge.spring.bootstrap;

import io.tugrandsolutions.flowforge.spring.annotations.FlowTask;
import io.tugrandsolutions.flowforge.spring.api.FlowTaskHandler;
import io.tugrandsolutions.flowforge.spring.registry.RegisteredTaskHandler;
import io.tugrandsolutions.flowforge.spring.registry.TaskHandlerRegistry;
import io.tugrandsolutions.flowforge.task.TaskId;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.context.ApplicationContext;

import java.util.Map;

public final class TaskScanner implements SmartInitializingSingleton {

    private final ApplicationContext ctx;
    private final TaskHandlerRegistry registry;

    public TaskScanner(ApplicationContext ctx, TaskHandlerRegistry registry) {
        this.ctx = ctx;
        this.registry = registry;
    }

    @Override
    public void afterSingletonsInstantiated() {
        Map<String, Object> beans = ctx.getBeansWithAnnotation(FlowTask.class);

        for (Object bean : beans.values()) {
            FlowTask ann = bean.getClass().getAnnotation(FlowTask.class);

            if (!(bean instanceof FlowTaskHandler<?, ?> handler)) {
                throw new IllegalStateException(
                        "@FlowTask requires bean implements FlowTaskHandler: " + bean.getClass().getName()
                );
            }

            TaskId id = new TaskId(ann.id());
            registry.register(new RegisteredTaskHandler(id, ann.optional(), handler));
        }
    }
}