package io.tugrandsolutions.flowforge.spring.annotations;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface FlowTask {
    String id();
    boolean optional() default false;
}