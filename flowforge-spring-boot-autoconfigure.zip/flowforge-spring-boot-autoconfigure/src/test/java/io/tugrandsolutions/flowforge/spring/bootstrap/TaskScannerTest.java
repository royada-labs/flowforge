package io.tugrandsolutions.flowforge.spring.bootstrap;

import io.tugrandsolutions.flowforge.spring.annotations.FlowTask;
import io.tugrandsolutions.flowforge.spring.api.FlowTaskHandler;
import io.tugrandsolutions.flowforge.spring.autoconfig.FlowForgeAutoConfiguration;
import io.tugrandsolutions.flowforge.spring.registry.TaskHandlerRegistry;
import io.tugrandsolutions.flowforge.task.TaskId;
import io.tugrandsolutions.flowforge.workflow.ReactiveExecutionContext;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.*;

class TaskScannerTest {

    private final ApplicationContextRunner contextRunner =
            new ApplicationContextRunner()
                    .withUserConfiguration(ImportAutoConfig.class);

    @Test
    void should_register_flow_tasks_annotated_beans() {
        contextRunner
                .withUserConfiguration(ValidTasksConfig.class)
                .run(ctx -> {
                    assertNull(ctx.getStartupFailure(), "Context startup should not fail");

                    TaskHandlerRegistry registry = ctx.getBean(TaskHandlerRegistry.class);

                    assertTrue(registry.contains(new TaskId("A")));
                    assertTrue(registry.contains(new TaskId("B")));
                    assertEquals(2, registry.snapshot().size());

                    var a = registry.find(new TaskId("A")).orElseThrow();
                    var b = registry.find(new TaskId("B")).orElseThrow();

                    assertFalse(a.optional(), "Task A optional should be false");
                    assertTrue(b.optional(), "Task B optional should be true");
                });
    }

    @Test
    void should_fail_on_duplicate_task_id() {
        contextRunner
                .withUserConfiguration(DuplicateTasksConfig.class)
                .run(ctx -> {
                    Throwable failure = ctx.getStartupFailure();
                    assertNotNull(failure, "Context should fail on duplicate task id");
                    assertTrue(
                            failure.getMessage() != null && failure.getMessage().contains("Duplicate FlowTask id"),
                            "Expected message containing 'Duplicate FlowTask id' but was: " + failure.getMessage()
                    );
                });
    }

    @Test
    void should_fail_when_annotated_bean_does_not_implement_handler() {
        contextRunner
                .withUserConfiguration(InvalidTaskBeanConfig.class)
                .run(ctx -> {
                    Throwable failure = ctx.getStartupFailure();
                    assertNotNull(failure, "Context should fail when @FlowTask bean is not a handler");
                    assertTrue(
                            failure.getMessage() != null && failure.getMessage().contains("@FlowTask requires bean implements FlowTaskHandler"),
                            "Expected message containing handler requirement but was: " + failure.getMessage()
                    );
                });
    }

    @Configuration(proxyBeanMethods = false)
    @Import(FlowForgeAutoConfiguration.class)
    static class ImportAutoConfig { }

    @Configuration(proxyBeanMethods = false)
    static class ValidTasksConfig {
        @Bean TaskA taskA() { return new TaskA(); }
        @Bean TaskB taskB() { return new TaskB(); }
    }

    @Configuration(proxyBeanMethods = false)
    static class DuplicateTasksConfig {
        @Bean TaskA taskA() { return new TaskA(); }
        @Bean TaskADuplicateId taskADuplicateId() { return new TaskADuplicateId(); }
    }

    @Configuration(proxyBeanMethods = false)
    static class InvalidTaskBeanConfig {
        @Bean NotAHandlerBean notAHandlerBean() { return new NotAHandlerBean(); }
    }

    // ---------- Test beans ----------

    @FlowTask(id = "A", optional = false)
    static class TaskA implements FlowTaskHandler<Void, Integer> {
        @Override public Mono<Integer> execute(Void input, ReactiveExecutionContext ctx) {
            return Mono.just(1);
        }
    }

    @FlowTask(id = "B", optional = true)
    static class TaskB implements FlowTaskHandler<Integer, Integer> {
        @Override public Mono<Integer> execute(Integer input, ReactiveExecutionContext ctx) {
            return Mono.just(input == null ? 0 : input + 1);
        }
    }

    @FlowTask(id = "A")
    static class TaskADuplicateId implements FlowTaskHandler<Void, Integer> {
        @Override public Mono<Integer> execute(Void input, ReactiveExecutionContext ctx) {
            return Mono.just(2);
        }
    }

    @FlowTask(id = "X")
    static class NotAHandlerBean { }
}
