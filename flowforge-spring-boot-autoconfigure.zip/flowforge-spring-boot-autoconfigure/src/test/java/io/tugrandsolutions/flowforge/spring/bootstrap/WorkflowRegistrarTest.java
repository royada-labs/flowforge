package io.tugrandsolutions.flowforge.spring.bootstrap;

import io.tugrandsolutions.flowforge.spring.annotations.FlowTask;
import io.tugrandsolutions.flowforge.spring.annotations.FlowWorkflow;
import io.tugrandsolutions.flowforge.spring.api.FlowTaskHandler;
import io.tugrandsolutions.flowforge.spring.autoconfig.FlowForgeAutoConfiguration;
import io.tugrandsolutions.flowforge.spring.registry.WorkflowPlanRegistry;
import io.tugrandsolutions.flowforge.workflow.ReactiveExecutionContext;
import io.tugrandsolutions.flowforge.workflow.plan.WorkflowExecutionPlan;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class WorkflowRegistrarTest {

    private final ApplicationContextRunner runner =
            new ApplicationContextRunner()
                    .withUserConfiguration(ImportAutoConfig.class);

    @Test
    void should_register_workflow_plan_from_annotated_bean() {
        runner.withUserConfiguration(ValidWorkflowConfig.class)
                .run(ctx -> {
                    assertNull(ctx.getStartupFailure());

                    WorkflowPlanRegistry registry = ctx.getBean(WorkflowPlanRegistry.class);

                    assertTrue(registry.contains("api-score"));
                    WorkflowExecutionPlan plan = registry.find("api-score").orElseThrow();

                    // sanity checks: el plan no es null y tiene nodos
                    assertFalse(plan.nodes().isEmpty());
                    assertEquals(1, plan.roots().size());
                });
    }

    @Configuration(proxyBeanMethods = false)
    @Import(FlowForgeAutoConfiguration.class)
    static class ImportAutoConfig { }

    @Configuration(proxyBeanMethods = false)
    static class ValidWorkflowConfig {

        @Bean TaskA taskA() { return new TaskA(); }
        @Bean TaskB taskB() { return new TaskB(); }

        @Bean
        @FlowWorkflow(id = "api-score")
        WorkflowExecutionPlan apiScoreWorkflow() {
            io.tugrandsolutions.flowforge.task.TaskDescriptor a = new io.tugrandsolutions.flowforge.task.TaskDescriptor(new io.tugrandsolutions.flowforge.task.TaskId("A"), false, Set.of());
            io.tugrandsolutions.flowforge.task.TaskDescriptor b = new io.tugrandsolutions.flowforge.task.TaskDescriptor(new io.tugrandsolutions.flowforge.task.TaskId("B"), false, Set.of(new io.tugrandsolutions.flowforge.task.TaskId("A")));

            return io.tugrandsolutions.flowforge.workflow.plan.WorkflowPlanBuilder.build(List.of(a, b)); // o como se llame en tu core
        }
    }

    @FlowTask(id = "A")
    static class TaskA implements FlowTaskHandler<Void, Integer> {
        @Override public Mono<Integer> execute(Void input, ReactiveExecutionContext ctx) {
            return Mono.just(1);
        }
    }

    @FlowTask(id = "B")
    static class TaskB implements FlowTaskHandler<Integer, Integer> {
        @Override public Mono<Integer> execute(Integer input, ReactiveExecutionContext ctx) {
            return Mono.just((input == null ? 0 : input) + 1);
        }
    }
}
